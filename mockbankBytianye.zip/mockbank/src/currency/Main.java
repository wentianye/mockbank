package currency;

import java.io.*;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Main {

    private static final Pattern INPUT_PATTERN = Pattern.compile("^[A-Z]{3}\\s-?\\d+$");

    private static final ConcurrentHashMap<String, BigInteger> BANK = new ConcurrentHashMap<>();

    private static final long INTERVAL = 60 * 1000;

    private static final double CNY_EXCHANGE=0.14;

    public static void main(String[] args) {
        //Step 1 read optional file
        if (args.length > 0) {
            readCurrencyFile(args[0]);
        }

        //Step 2 setup scheduled task
        new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(INTERVAL);
                    printNetAmount();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }).start();

        //Step 3 listen console input
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext()) {
            String input = scanner.nextLine();
            Matcher matcher = INPUT_PATTERN.matcher(input);
            if (matcher.find()) {
                //transaction
                transaction(input.substring(0, 3), new BigInteger(input.substring(4)));
            } else {
                if (input.equals("quit")) {
                    System.exit(0);
                }
                //invalid input
                System.out.println("invalid input");
            }
        }
    }

    /**
     * read currency amount from a file
     *
     * @param filePath path where file stored
     */
    public static void readCurrencyFile(String filePath) {
        File file = new File(filePath);
        if (file.exists()) {
            try {
                Files.lines(Paths.get(filePath)).forEach(s -> {
                    Matcher matcher = INPUT_PATTERN.matcher(s);
                    if (matcher.find()) {

                        String currency = s.substring(0, 3);
                        BigInteger amount = new BigInteger(s.substring(4));

                        //save it to bank
                        BigInteger balance = BANK.getOrDefault(currency, new BigInteger("0"));
                        BANK.put(currency, balance.add(amount));
                    }
                });

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * check the bank
     * print all the currency code and net amount when its net amount are not zero
     */
    public static void printNetAmount() {
        BANK.entrySet().stream()
                .filter(entry -> entry.getValue().compareTo(BigInteger.ZERO) != 0)
                .forEach(Main::printBalance);

    }

    /**
     * print Entry
     *
     * @param entry entry which combines currency code and amount
     */
    public static void printBalance(Map.Entry<String, BigInteger> entry) {
        switch (entry.getKey()){
            case "CNY":
                Double cnyToUsd=entry.getValue().doubleValue()*CNY_EXCHANGE;
                System.out.println(entry.getKey() + " " + entry.getValue()+"(USD:"+cnyToUsd+")");
                break;
            default:
                System.out.println(entry.getKey() + " " + entry.getValue());

        }
    }

    /**
     * thread-safe bank transaction
     *
     * @param currency currency code
     * @param amount   amount
     */
    public static void transaction(String currency, BigInteger amount) {
        synchronized (BANK) {
            BigInteger balance = BANK.getOrDefault(currency, new BigInteger("0"));
            balance = balance.add(amount);
            BANK.put(currency, balance);
        }
    }
}
